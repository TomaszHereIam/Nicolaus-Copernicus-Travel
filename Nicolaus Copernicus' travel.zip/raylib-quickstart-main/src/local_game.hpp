static int is_boss_fight = 0;

#ifndef LOCAL_GAME_HPP
#define LOCAL_GAME_HPP
#include "raylib.h"
#include "animation.hpp"
#include "game.hpp"
#include "postac.hpp"
#include <cstdint>
#include <vector>



static int sound_index = 0;

static int coin_ammount = 0;

void PauseAllSoundsExcept(std::vector<Sound> &sounds, int index) {
	for(int j = 0; j < sounds.size(); j++) {
	  if(j != index) PauseSound(sounds[j]);
	}
  }

  
class Trex : public GameObject {
	private:
	int random_num;
	bool one_iteration = 1;
	public:
    
    Texture laser_texture;
	Animation animation = Animation(0, 0, 200, 200, 4, 1);

	Postac* postac;
	float limit_right;
	float limit_left;
	bool is_left = false;
	bool is_paused = false;
	int pause_time;
	int counter = 0;
	int cooldown;


	bool is_attacking = false;
	int* boss_hp;


	float* target_x;
	float* target_y;
    int* target_hp;
    Rectangle* target_hitbox;
	int_fast16_t* render_int;
	bool is_activated = false;


	Rectangle attack_rectngle;
    Rectangle source_rectangle;


	// asimptots
	Sciana a1;
	Sciana a2;
	
	std::vector<std::vector<Vector2>> positions;
	
	Trex(float get_x, float get_y, float get_width, float get_height) {
		x = get_x;
		y = get_y;
		width = get_width;
		height = get_height;
	
		general_hitbox = Rectangle{x+10, y+10, width-10, 140};
		source_rectangle = Rectangle{x, y, width, height};
		
		animation.dest_rectangle = &source_rectangle;
        

		HT=  BOTH;
		OT = ENEMY;

		a1 = Sciana(6350, 100, 500);
		a2 = Sciana(7040, 100, 500);
		
       // animation.frequency == -1;
	 //	Animation.animate(1, 2, 3)
	 should_destroy = false;
	 is_activated = false;
	}

   
	void Update() {
      if(*boss_hp <= 0) return;
	  if(target_hitbox->x < limit_left) return;
	  
      if(one_iteration = false) {
		one_iteration = true;
		return;
	  }
	
		if(counter < pause_time){
			
			counter--;
			if(pause_time > counter && counter > pause_time/2) is_attacking = true;
			if(counter == pause_time/2) is_attacking = false;
		 }

		if(counter == 0) {
			counter = pause_time;
			is_paused = false;
	

			if(is_left && x > limit_left) x-=1;
            if(!is_left && x < limit_right)  x+=1;
			
		}

		animation.is_left = is_left;

		if(is_paused && counter > 0) counter--;

		// movement & attack
	if(!is_paused) {	
		if(is_left && x > limit_left) x-=1;
        if(!is_left && x < limit_right)  x+=1;
		
		if(x <= limit_left) {

		is_left = false; is_paused = true; 
		random_num = GetRandomValue(0, 2);
	    animation.SetCurrentFrame(random_num+1);
		attack_rectngle = Rectangle{positions[random_num][is_left].x, positions[random_num][is_left].y, 600, 40}; 

	}
		if(x >= limit_right) {
			
			is_left = true; is_paused = true; 
		
			random_num = GetRandomValue(0, 2);
			animation.SetCurrentFrame(random_num+1);
			attack_rectngle = Rectangle{positions[random_num][is_left].x, positions[random_num][is_left].y, 600, 40}; 
		}
     
		general_hitbox = Rectangle{x+10, y+80, width-20, 140};
		source_rectangle = Rectangle{x, y, width, height};
	}
   
		if(target_hitbox->x > limit_left) is_activated = true;
	 if(is_activated) {
		
		postac->is_colliding_left_hitbox = false;
		postac->is_colliding_right_hitbox = false;
		if(CheckCollisionRecs(a1.general_hitbox, postac->left_hitbox)) {
			postac->is_colliding_left_hitbox = true;
		} else {
		  if(CheckCollisionRecs(a2.general_hitbox, postac->right_hitbox)) {
			  postac->is_colliding_right_hitbox = true;
		  }
  
		}

	

	 }
  
    if(is_attacking && is_activated) {
	  if(CheckCollisionRecs(attack_rectngle, *target_hitbox)) {

        *target_hp = 0;
		x = limit_right;
		*boss_hp = 5;
		is_attacking = false;
		is_left = true;
		is_boss_fight = 0;
		//*render_int = 0;
		*target_x = postac->respawn_x;
		*target_y = postac->respawn_y;
    
		is_paused = false;
		is_activated= false;
		one_iteration = false;
	  
	  }
	}
	  if(CheckCollisionRecs(general_hitbox, *target_hitbox)) {
	//	postac->camera.target = Vector2{target_hitbox->x, target_hitbox->y};
	

		*target_x = postac->respawn_x;
		*target_y = postac->respawn_y;
		is_boss_fight = 0;
		*boss_hp = 5;

		is_activated = false;
		is_paused = true;
		is_left = true;
		one_iteration = false;
	
	  }
	

	 
	  
	  if(*boss_hp <= 0) {
		should_destroy = true;
		return;
	}

	  if(counter == (pause_time/2)-1) animation.SetCurrentFrame(1);
 	}

	 

	void DrawLaser() {
		DrawTexturePro(laser_texture, Rectangle{0, 0, 40, 20}, attack_rectngle, Vector2{0, 0}, 0.0F, WHITE);
	}

	void DrawHealthBar() {
		DrawRectangle(x+40, y, 20*(*boss_hp), 10, GREEN);
	}


	void DrawHitbox() {

		DrawRectangleLinesEx(general_hitbox, 4, RED);
		a1.DrawHitbox();
		a2.DrawHitbox();
	}

	void Draw() {
		if(*boss_hp <= 0) return;
        animation.Draw();
		DrawHealthBar();
        if(pause_time > counter && counter > pause_time/2) DrawLaser();   
	}
 
	
  };

  class Knight : public GameObject{ // dimensions 80 x 40
	private: 
	int counter = 0;
	public: 
  
	
   
	float limit_left;
	float limit_right;
	float pause_time;
	float velocity;
	int frames_left = 0;
  
	bool is_left = false;
	bool is_activated = false;


	Sciana a1;
	Sciana a2;

  
	// pointers
	Postac* postac;
  
  
	Texture texture;
   
	Knight(float get_x, float get_y, float get_width, float get_height, int get_pause_time) {
	 x = get_x;
	 y = get_y;
	 width = get_width;
	 height = get_height;
   
	 general_hitbox = Rectangle{x, y, width, height};
  
	 pause_time = get_pause_time;
	 counter = pause_time;

	 OT = ENEMY;
	 HT = BOTH;
 
	 a1 = Sciana(2600, 100, 500);
	 a2 = Sciana(3200, 100, 500);

	 hp = 60;
	}
  
	void DrawHealthBar() {
		DrawRectangle(x+20, y-20, hp, 10, GREEN);
	   }
  
   void Draw() {
	if(hp <= 0) return;
	DrawHealthBar();
	if(!is_left)  {
	  DrawTexturePro(texture, Rectangle{0, 0, -100, 70}, Rectangle{general_hitbox}, Vector2{0, 0}, 0.0F, WHITE);
	  return;
	}
	 DrawTexture(texture, x, y, WHITE);
   }
  
   void Update() {
  
	if(hp <= 0 ) {
		should_destroy = true;
		return;
	}

	if(postac->x > limit_left) is_activated = true;
	if(!is_activated) return;


		
		postac->is_colliding_left_hitbox = false;
		postac->is_colliding_right_hitbox = false;
		if(CheckCollisionRecs(a1.general_hitbox, postac->left_hitbox)) {
			postac->is_colliding_left_hitbox = true;
		} else {
		  if(CheckCollisionRecs(a2.general_hitbox, postac->right_hitbox)) {
			  postac->is_colliding_right_hitbox = true;
		  }
  
		}
	 
  
	if(counter == pause_time) {
	if(is_left) {
	if(x <= limit_right)  {
	  x+=velocity;
	} else {
	 is_left = false;
	 frames_left--;
	 if(frames_left == 0) counter--;
	}
  
	} else {
	  if(x >= limit_left)  {
		x-=velocity;
	  } else {
	   is_left = true;
	   frames_left--;
	   if(frames_left == 0) counter--;
	  }
	}
    
	

	if(CheckCollisionRecs(general_hitbox, postac->general_hitbox)) {
		postac->hp = 0;
		hp = 80;
		is_activated = false;
		x = limit_right;
	}
	
  
   }
   
  
  
   if(counter < pause_time) counter--;
   if(counter == 0) {counter = pause_time; frames_left--;}

	if(frames_left == -1) frames_left = GetRandomValue(3, 5);
  
  
	
	general_hitbox = Rectangle{x, y, width, height};
	}
  
   

   void Test() {
	DrawText(TextFormat("%d", frames_left), 100, 100, 20, BLACK);
   }
};
  

  class PlanetGun : public GameObject { // aka Planet Gun
   private:
   int counter = 0;
   int c2 = 0;
   int cooldown_counter;
   int arise_frequency;

   public:


   
   int hp;

   int current_pos;
   int current_planet;
   bool can_damage = false;
   bool is_collected = false;
   float velocity_x;

   Texture texture;

   Rectangle general_hitbox;
   Rectangle source_rectangle;

   // pointers

   Rectangle* friendly_hitbox;
   Rectangle* enemy_hitbox;
   bool* is_left;
   int* enemy_hp;
   


   Vector2 positions[5];

 PlanetGun(float get_x, float get_y, float get_width, float get_height, int get_arise_frequency) {
    x = get_x;
    y = get_y;
    width = get_width;
    height = get_height;

    general_hitbox = Rectangle{x, y, width, height};
	source_rectangle = {0, 0, width, height};

	arise_frequency = get_arise_frequency;
	counter = arise_frequency;
	c2 = 60;

	OT = UTILITY;
	HT = BOTH;

  }

     void Spawn() {
      current_pos = GetRandomValue(0, 4);
	  current_planet = GetRandomValue(0, 5);

	  x = positions[current_pos].x;
	  y = positions[current_pos].y;
         
	  source_rectangle.x = (current_pos*width);


	  is_collected = false;
	  can_damage = false;
	 }
	 void Update() {
       if(friendly_hitbox->x < 6350) {
		can_damage = false;
		is_collected = false;
	   }
		general_hitbox = Rectangle{x, y, width, height};

		if(c2 < 60) c2--;
		if(c2 == 0) c2 = 60;
		if(counter < arise_frequency && counter > 0) counter--;
		if(counter > arise_frequency) counter++;
		if(counter == 0 && c2 == 60) {
			Spawn();
			counter = arise_frequency;
		}
		if(counter == 2*arise_frequency) {
			Spawn();
			counter = arise_frequency;
		}

       if(!can_damage && !is_collected) {
         if(CheckCollisionRecs(general_hitbox, *friendly_hitbox) && c2 == 60) {
			is_collected = true;
			can_damage = false;
		 }
	   }
	   if(can_damage && !is_collected) {
		if(counter > arise_frequency) {
             x-=velocity_x;
		}
		if(counter < arise_frequency) {
			x+=velocity_x;
		}

		if(CheckCollisionRecs(general_hitbox, *enemy_hitbox)) {
			*enemy_hp = *enemy_hp-1;
			can_damage = false;
			//Spawn();
			c2--;
			counter = 0;
		}
		
	   }

	   if(!can_damage && is_collected) {

		if(IsKeyPressed(KEY_R)) {
            if(*is_left) {
              counter++;
			} else {
				counter--;
			}
			is_collected = false;
			can_damage = true;
		 }

	if(*is_left) {	
		x = friendly_hitbox->x-30;
		y = friendly_hitbox->y+26;
	} else {
		x = friendly_hitbox->x+30;
		y = friendly_hitbox->y+26;
	}
	   }

	 }

	 void Draw() {
		if(c2 < 60) return;
        if(!is_collected) {
			DrawTexturePro(texture, source_rectangle, general_hitbox, Vector2{0, 0}, 0.0F, WHITE);
		}
	 }

	 void DrawHitbox() {
		if(c2 < 60) return;
		DrawRectangleLinesEx(general_hitbox, 4, DARKBLUE);
	 }
  };

  class Kregiel : public GameObject {
	private:
	int counter = 0;
   public:

   Postac* postac;
   Texture texture;
   
   Kregiel(float get_x, float get_y, float get_width, float get_height, Postac* get_postac, Texture get_texture) {
    x = get_x;
    y = get_y;
    width = get_width;
    height = get_height;
	postac = get_postac;
	texture = get_texture;

	hp = 5;
  
	OT = ENEMY;
	HT = BOTH;

	

    general_hitbox = Rectangle{x, y, width, height};
	counter = 60;
}

  void DrawHealthBar() {
     DrawRectangle(x+10, y-10, 4*hp, 5, GREEN);
  }
   void Draw() {
	if(hp <= 0) should_destroy = true;
     if(hp <= 0) return;
	 DrawTexture(texture, x, y, WHITE); 
	 DrawHealthBar();
   }

   void Update() {
	if(hp <= 0) should_destroy = true;
	if(hp <= 0) return;
      if(CheckCollisionRecs(general_hitbox, postac->general_hitbox) && counter == 60) {
        postac->hp--;
		counter--;
	  }
	  if(counter < 60) counter--;
	  if(counter == 0) counter = 60;
   }
  };

  class StrzelajacyKregiel : public GameObject {
	

	public:

	int counter = 90;
	int c2 = 0;
	Postac* postac;
	Texture texture;
	Texture bulled_texture;

	Rectangle damage_hitbox;

	bool can_damage = true;
	
	StrzelajacyKregiel(float get_x, float get_y, float get_width, float get_height, Postac* get_postac, Texture get_texture, Texture get_bulled_texture) {
	 x = get_x;
	 y = get_y;
	 width = get_width;
	 height = get_height;
	 postac = get_postac;

	 texture = get_texture;
	 bulled_texture = get_bulled_texture;
 
	 hp = 5;
   
	 OT = ENEMY;
	 HT = BOTH;
 
	 
     c2 = 60;
	 general_hitbox = Rectangle{x, y, width, height};

	 damage_hitbox = Rectangle{x+10, y+16, 12, 12};
 }

 void DrawHealthBar() {
	DrawRectangle(x+10, y-10, 4*hp, 5, GREEN);
 }
 
	void Draw() {
	
		if(hp == 0) should_destroy = true;
	  if(hp <= 0) return;
	  DrawTexture(texture, x, y, WHITE); 
         if(c2 < 60) return;
	  DrawRectangleRec(damage_hitbox, BLACK);
	  DrawHealthBar();
	}

	void DrawHitbox() {
		if(c2 < 60) return;
		if(hp == 0) should_destroy = true;
		DrawRectangleLinesEx(general_hitbox, 4, RED);
		DrawRectangleLinesEx(damage_hitbox, 3, RED);
	}
 
	void Update() {
		if(c2 < 60) c2--;
		if(c2 == 0) c2 = 60;
		if(c2 < 60) return;
		if(hp == 0) should_destroy = true;
	 if(hp <= 0) return;
	 if(counter == 120) {
	  counter--;
	  can_damage = true;
	 }

	 if(counter < 120) {
		counter--;
	   damage_hitbox.x-=1.6;
	 }
	 if(counter == 0) {
	  counter = 120;
	  damage_hitbox.x = x+10;
	 }

	 if(CheckCollisionRecs(damage_hitbox, postac->general_hitbox)) {
       counter = 90;
	   postac->hp--;
	   damage_hitbox.x = x+10;
	   can_damage = false;
	   c2--;
	 }
	
	}
  };

  class DomekZPiernikami : public GameObject {
	public:

	Postac* postac;
	Texture texture;
	
	DomekZPiernikami(float get_x, float get_y, float get_width, float get_height, Postac* get_postac, Texture get_texture) {
	 x = get_x;
	 y = get_y;
	 width = get_width;
	 height = get_height;
	 postac = get_postac;
	 texture = get_texture;
 
	 hp = 1;
   
	 OT = UTILITY;
	 HT = BOTH;
 
	 
 
	 general_hitbox = Rectangle{x, y, width, height};
 }
 
	void Draw() {
	  DrawTexture(texture, x, y, WHITE); 
	}
 
	void Update() {
	 if(hp <= 0) return;
	   if(CheckCollisionRecs(general_hitbox, postac->general_hitbox)) {

		DrawText("Domek Piernikowy \nJeden Piernik - 2 zl\nPiernik dodaje +100% zdrowia", x + 60, y+20, 20, BLUE);
		 if(IsKeyPressed(KEY_E)) {
			if(coin_ammount >= 2) {
                coin_ammount-=2;
				postac->hp += postac->max_hp;
				postac->max_hp *= 2;
			}
		 }
	   }
	}
  };




  #endif

