#pragma once
#include "game.hpp"

void Mapa::Draw() {
  DrawTexture(texture, x, y, WHITE);
};

void GameObject::DrawHitbox() {
    DrawRectangleLinesEx(general_hitbox, 4, RED);
}

void Podloga::Setup() {
    general_hitbox = Rectangle{x, y, width, height};
}

void Checkpoint::Update() {
    if(CheckCollisionRecs(Rectangle{*x_now, *y_now, 36, 56}, general_hitbox) && *current_respawn_x < x) {
       *current_respawn_x = x;
       *current_respawn_y = y-10;
       is_checked++;
    }
}

void Checkpoint::Draw() {
  DrawTexturePro(spritesheet, Rectangle{0+is_checked*width, 0, width, height}, general_hitbox, Vector2{0, 0}, 0.0f, WHITE);
}



// void Train::Draw() {
//  DrawTexture(texture, x, y, WHITE);
// }

// void Train::Update(float &target_x, bool &target_bool) {
//  if(x >= destinition) {target_bool = true;} else {
//   x+=vx;
//   target_x+=vx;
//  }
// }


// /*
// class DarkKnight {
// 	private:
// 	int timer = 0;
// 	public:
// 	float x;
// 	float y;
// 	float width;
// 	float height;
   
// 	Rectangle general_hitbox;
// 	Texture *sprite_sheet;
// 	int m;
// 	int n;
// 	int hp;
  
// 	int frequency; // frames
// 	int cooldown; // frames
// 	int damage_per_attack;
    
// 	Postac *postac;

// 	void Draw() {
//      if(hp > 0)  DrawTexture(*sprite_sheet, x, y, WHITE);
// 	}
// 	void DrawHitbox() {
// 		DrawRectangleLinesEx(general_hitbox, 4, RED);
// 	}

// 	void Setup() {
		
// 			general_hitbox = Rectangle{x, y, width, height};
// 			timer = cooldown;	
// 	};

// 	void Update() {
// 		if(hp > 0) {
// 		if(timer < cooldown) timer--;
// 		if(timer == 0) timer = cooldown;

// 		if(timer == cooldown && CheckCollisionRecs(general_hitbox, postac->general_hitbox)) {
//           postac->hp--;
// 		  timer--;
// 		}
// 	}
// 	}
// 	// void DrawHP();
// 	// void Update();
//   };
//   */