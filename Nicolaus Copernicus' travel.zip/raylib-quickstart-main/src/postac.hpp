#include "raylib.h"
#include "animation.hpp"
#include <cstdint>


/*
basic postac dimension is 72 x 112, and because our base resolution is 640 x 360 we have to rescale it to 36 x 56
*/

#ifndef POSTAC_HPP
#define POSTAC_HPP

class Postac {
    private:
    int jump_timer;
    int animation_frame;
    bool is_first_frame = false;
 public:
 
 // movement
 float x;
 float y;
 float width;
 float height;

 // camera

 Camera2D camera;
 float dx;
 float dy;
 

 int fps;
 float jump_power;
 float jump_time;
 float velocity_x;
 float gravity;
 float fall_velocity = 0;
 bool is_jumping = false;
 

 // game variables
 int hp = 5;
 int max_hp = 5;
 float respawn_x;
 float respawn_y;
 float max_y;
 int_fast16_t *render;
 bool is_hibernated = true;

 // hitboxes;

 Rectangle general_hitbox; 

 Rectangle bottom_hitbox;
 Rectangle top_hitbox;
 Rectangle right_hitbox;
 Rectangle left_hitbox;

 // bools
 bool is_colliding_general_hitbox = false;
 bool is_colliding_top_hitbox= false;
 bool is_colliding_bottom_hitbox= false;
 bool is_colliding_right_hitbox= false;
 bool is_colliding_left_hitbox= false;



 // draw and texture
 Texture sprite_sheet;
 Texture current_texture;
 // general hitbox is always the destinated rectangle
 Animation animation;
 int sprite_m;
 int sprite_n;
 int frequency;
 bool is_left = false;
 bool is_holding_animation = false;

 


 // matrix M n,m


 // methods
 void Setup();
 void Draw();
 void DrawHealthBar();
 void DrawHitbox();
 void Update();
 void Respawn();
 void UpdateFPS(int new_fps);
 
// void Respawn();


};


#endif