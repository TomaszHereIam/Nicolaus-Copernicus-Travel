// #pragma once
// #include "item.hpp"

// void Bullet::Draw() {
//     DrawTexture(texture, x, y, WHITE);
// }

// void Bullet::DrawHitbox() {
//     DrawRectangleLinesEx(general_hitbox, 4, RED);
// }


// void Bullet::Update() {
//   x+=vx;
//   general_hitbox.x+=vx;

//   timer--;
// }

// void Gun::DrawHitbox() {
//     for(int j = 0; j < bullets.size(); j++) {
//         bullets[j].DrawHitbox();
//      }
// }

// void Gun::Draw() {
//     for(int j = 0; j < bullets.size(); j++) {
//        bullets[j].Draw();
//     }
// }

// void Gun::Update() {

//    if(timer < cooldown) timer--;
//    if(timer == 0) timer = cooldown;

//   for(int j = 0; j < bullets.size(); j++) {
  
//     bullets[j].Update();
//  //   if(bullets[j].timer <= 0) bullets.erase(bullets.begin()+j, bullets.begin()+j+1);
//   }


//   if(IsMouseButtonPressed(MOUSE_BUTTON_LEFT)) { 
   
//     //  bullets.push_back(Bullet(x, y, 20, -2, 180, ammo_texture));
//      DrawText("TRUE", 400, 400, 20, BLUE);
//       bullets.push_back(Bullet(x, y, 20, 4, 180, ammo_texture));
    
//     timer--;
//   }

  


// }