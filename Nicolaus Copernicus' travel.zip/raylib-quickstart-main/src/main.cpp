/*
Raylib example file.
This is an example main file for a simple raylib project.
Use this as a starting point or replace it with your code.

by Jeffery Myers is marked with CC0 1.0. To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/

*/

#include "raylib.h"
#include "postac.hpp"
#include "resource_dir.h"	// utility header for SearchAndSetResourceDir
#include "game.hpp"
 #include "animation.hpp"
//#include "enemy.hpp"
#include "local_game.hpp"

#include <vector>
#include <algorithm>


int_fast16_t current_frame = 0;

class Bullet {
	public:
	int timer;
	Texture texture;
	
   
	float x;
	float y;
	float side;
	float vx;
	float lifespan;
   
	Rectangle general_hitbox;
   
	Bullet(float get_x, float get_y, float get_side, float get_vx, float get_lifespan, Texture get_texture) {
	  x = get_x;
	  y = get_y;
	  side = get_side;
	  lifespan = get_lifespan;
	  vx = get_vx;
	  timer = lifespan;
   
	  general_hitbox = Rectangle{x, y, side, side};
   
   
	  texture = get_texture;
   
	}
   
	void Draw() {
		DrawTexture(texture, x, y, WHITE);
	}
	
	void DrawHitbox() {
		DrawRectangleLinesEx(general_hitbox, 4, RED);
	}
	
	
	void Update() {
	  x+=vx;
	  general_hitbox.x+=vx;
	
	  timer--;
	}
   
   };


std::vector<GameObject*> GameObjects;

std::vector<GameObject*> Enemies;
std::vector<GameObject*> Utilities;	// every utility should be allocated in dynamic memory
std::vector<GameObject*> VerticalHitboxes;
std::vector<GameObject*> HorizontalHitboxes;






void Remove(std::vector<GameObject*> &_GameObjects, GameObject* element) {
	auto obj = std::lower_bound(_GameObjects.begin(), _GameObjects.end(), (element->x+1), [](auto a, auto b) {return a->x < b;} );
	int index = std::distance(_GameObjects.begin(), obj);
  


	for(int j = index; j > 0; j--) {
		if(_GameObjects[j] == element) {
			_GameObjects.erase(_GameObjects.begin()+j, _GameObjects.begin()+j+1);
			// delete this;
		}
	}
  
  
  }

  void Destroy(std::vector<GameObject*> &_GameObjects, GameObject* elementt)  {
	Remove(_GameObjects, elementt); 
	delete elementt;
  }



class Coin :  public GameObject {
 public:
 
 Postac* postac;
 Texture texture;

 Coin(float get_x, float get_y, float get_width, Postac* get_postac, Texture get_texture) {
    x = get_x;
    y = get_y;
    height = get_width;
    width = get_width;
	postac = get_postac;

    OT = UTILITY;
    HT = BOTH;

	texture= get_texture;
    
	general_hitbox = Rectangle{x, y, width, height};
  }


 void Draw() {
    DrawTexture(texture, x, y, WHITE);
 } 
 bool can_add = true;


 void Update() {
   if(CheckCollisionRecs(general_hitbox, postac->general_hitbox)) {
  
	coin_ammount++;
	//can_add = false;
   
   should_destroy = true;
	
   }
 }
};

bool ValueCmp(GameObject* const & a, GameObject* const & b)
{
    return a->x < b->x;
}

class BlueBall {
	public:

	float x;
	float y;
	float radius;


	float* tp_x;
	float* tp_y;

	void Draw() {
		DrawText(TextFormat("%F, %F", x, y), x, y-20, 15, BLACK);
        DrawCircle(x, y, radius, BLUE);
	};

	void Update() {
		if(IsKeyDown(KEY_UP)) y-=2;
		if(IsKeyDown(KEY_DOWN)) y+=2;

		if(IsKeyDown(KEY_RIGHT)) x+=2;
		if(IsKeyDown(KEY_LEFT)) x-=2;

		if(IsKeyPressed(KEY_P)) {
			x = *tp_x;
			y = *tp_y;
		}

	}
};



class Shade2 {
	public:
	int counter = 0;


	unsigned char current = 0;
	int frequency;
	int velocity;
	Rectangle area;
   
	void Update() {
		counter++;

      if(counter == frequency) {
		if(current < 250) {
			current+=velocity;
		  }
		  if(current >= 250) current = 255;
		  if(current > 255) current = 255;
		  counter = 0;
		  if(frequency > 1) frequency--;
	  }
	}
  
	void Draw() {
       DrawRectangleRec(area, Color{0, 0, 0, current});
	}

	void DrawAreaHitbox() {
      DrawRectangleLinesEx(area, 5, RED);
	}
  };

  class Ender : public GameObject{
	public:

	int counter = 0;

	 Ender(float get_x, float get_y, float get_width, float get_height) {
		x = get_x;
		y = get_y;
		width = get_width;
		height = get_height;
	
		general_hitbox = Rectangle{x, y, width, height};
	}

	void Draw() {
      DrawText("Thanks to WMiI Torun", 8500, 800, 16, WHITE);
      DrawText("Graphics: CzajnikCzajnikCz", 8500, 1100, 16, WHITE);
	  DrawText("Graphics: Nameless Bowler", 8500, 1200, 16, WHITE);
	  DrawText("Programming: Tomsz Herlam", 8500, 1300, 15, WHITE);

	  DrawText("Educational And Open Source project", 8500, 1600, 20, WHITE);
	  DrawText("Kabanos Studio 1827-2027", 8500, 1800, 20, WHITE);

	  counter++;

	 // DrawText(TextFormat("%d", counter), 8500, y+20, 40, GREEN);
	}

	void Update() {
      y++;
	}
	
  };
 
int main ()
{
	// Tell the window to use vsync and work on high DPI displays
	SetConfigFlags(FLAG_VSYNC_HINT | FLAG_WINDOW_HIGHDPI);

	InitWindow(640, 360, "Podróż Kopernika");
	Image ikonka = LoadImage("resources/ikonka.png");
	SetWindowIcon(ikonka);
	UnloadImage(ikonka);
	InitAudioDevice();

	SearchAndSetResourceDir("resources");
	SetTargetFPS(60);

    std::vector<Sound> sounds(5);
	sounds[0] = LoadSound("sounds/theme.mp3");
	SetSoundVolume(sounds[0], 2.4);
	sounds[1] = LoadSound("sounds/medic.mp3");
	SetSoundVolume(sounds[1], 1.2);
	sounds[2] = LoadSound("sounds/bond.mp3");
	SetSoundVolume(sounds[2], 1.2);
	sounds[3] = LoadSound("sounds/refren.mp3");
	SetSoundVolume(sounds[3], 1.2);
	sounds[4] = LoadSound("sounds/reszta.mp3");
	SetSoundVolume(sounds[4], 2.4);
	

	Mapa map;
	map.x = -100;
	map.y = -100;

	map.texture = LoadTexture("mapa.png");
//
	Postac Kopernik;
	Kopernik.fps = 60;


	Kopernik.x = -700;
	Kopernik.y = 240;
	Kopernik.width = 36;
	Kopernik.height = 56;

	Kopernik.hp = 5;
	Kopernik.max_y = 1000;

	Kopernik.velocity_x = 120;
	Kopernik.gravity = 1;
	Kopernik.jump_power = 5;
	Kopernik.jump_time = 0.3; // seconds

	Kopernik.dx = -60.0F;
	Kopernik.dy = -360+56+20;
	Kopernik.frequency = 2;
    
	Kopernik.animation = Animation(0, 0, 36, 56, 4, 2);
	Kopernik.animation.source_texture = LoadTexture("spritesheet.png");
	Kopernik.animation.frequency = 10;
    

	Kopernik.camera.zoom = 1.0F;
	Kopernik.Setup();

    Texture ammo_texture = LoadTexture("pi1.png");
	Texture coin_texture = LoadTexture("coin.png");

	std::vector<Bullet> bullets;
 
   // Bullet bullet1 = Bullet(200, 200, 20, 1, 180, ammo_texture);


	
//  
 

     Rectangle source = Rectangle{0, 0, 36, 56};
	 


	 Train train1(-800, 220, 0, 400);
	 train1.texture = LoadTexture("train.png");
	 
	Texture baner = LoadTexture("baner.png");

   

	 Podloga podloga1 = Podloga(0, 360, 700);
	 podloga1.Setup();
	 GameObjects.push_back(&podloga1);
     HorizontalHitboxes.push_back(&podloga1);

	Checkpoint checkpoint1 = Checkpoint(30, 360-56, 36, 56);
	checkpoint1.x_now = &Kopernik.x;
	checkpoint1.y_now = &Kopernik.y;
	checkpoint1.current_respawn_x = &Kopernik.respawn_x;
	checkpoint1.current_respawn_y = &Kopernik.respawn_y;
	checkpoint1.spritesheet = LoadTexture("checkpoint.png");
	 GameObjects.push_back(&checkpoint1);


	 Checkpoint checkpoint2 = Checkpoint(1600, 340-56, 36, 56);
	checkpoint2.x_now = &Kopernik.x;
	checkpoint2.y_now = &Kopernik.y;
	checkpoint2.current_respawn_x = &Kopernik.respawn_x;
	checkpoint2.current_respawn_y = &Kopernik.respawn_y;
	checkpoint2.spritesheet = LoadTexture("checkpoint.png");
	 GameObjects.push_back(&checkpoint2);

	 Checkpoint checkpoint4 = Checkpoint(2100, 80-56, 36, 56);
	checkpoint4.x_now = &Kopernik.x;
	checkpoint4.y_now = &Kopernik.y;
	checkpoint4.current_respawn_x = &Kopernik.respawn_x;
	checkpoint4.current_respawn_y = &Kopernik.respawn_y;
	checkpoint4.spritesheet = LoadTexture("checkpoint.png");
	 GameObjects.push_back(&checkpoint4);


	 Checkpoint checkpoint3 = Checkpoint(5940, 550-56, 36, 56);
	 checkpoint3.x_now = &Kopernik.x;
	 checkpoint3.y_now = &Kopernik.y;
	 checkpoint3.current_respawn_x = &Kopernik.respawn_x;
	 checkpoint3.current_respawn_y = &Kopernik.respawn_y;
	 checkpoint3.spritesheet = LoadTexture("checkpoint.png");
	  GameObjects.push_back(&checkpoint3);

	 

	 Coin coin1 = Coin(400, 360-16, 16, &Kopernik, coin_texture);
	GameObjects.push_back(&coin1);

	 Podloga podloga2 = Podloga(800, 300, 200);
	 podloga2.Setup();
	 GameObjects.push_back(&podloga2);


	 Podloga podloga3 = Podloga(1000, 400, 300);
	 podloga3.Setup();
	 GameObjects.push_back(&podloga3);

	 Podloga podloga4 = Podloga(1400, 340, 300);
	 podloga4.Setup();
	 GameObjects.push_back(&podloga4);

	 Podloga podloga5 = Podloga(1850, 270, 100);
	 podloga5.Setup();
	 GameObjects.push_back(&podloga5);

	 Coin coin21 = Coin(1900, 270-16, 16, &Kopernik, coin_texture);
	 GameObjects.push_back(&coin21);

	 Podloga podloga6 = Podloga(2100, 210, 100);
	 podloga6.Setup();
	 GameObjects.push_back(&podloga6);

	 Coin coin14 = Coin(2150, 210-16, 16, &Kopernik, coin_texture);
	 GameObjects.push_back(&coin14);

	 Podloga podloga7 = Podloga(1850, 160, 100);
	 podloga7.Setup();
	 GameObjects.push_back(&podloga7);



	 Podloga podloga8 = Podloga(2000, 80, 300);
	 podloga8.Setup();
	 GameObjects.push_back(&podloga8);

	 Coin coin11 = Coin(2200, 80-16, 16, &Kopernik, coin_texture);
	 GameObjects.push_back(&coin11);


	 Podloga podloga9 = Podloga(2600, 300, 700);
	 podloga9.Setup();
	 GameObjects.push_back(&podloga9);

	 Coin coin114 = Coin(3460, 240-16, 16, &Kopernik, coin_texture);
	 GameObjects.push_back(&coin114);

	 Podloga podloga21= Podloga(3400, 240, 200);
	 podloga21.Setup();
	 GameObjects.push_back(&podloga21);


	 Kregiel k112 = Kregiel(3500, 240-60, 40, 60, &Kopernik, LoadTexture("kregiel.png"));
	 GameObjects.push_back(&k112);

	 StrzelajacyKregiel sk33 = StrzelajacyKregiel(3560, 240-50, 40, 50, &Kopernik, LoadTexture("strzelajacy_kregiel.png"), LoadTexture("domek.png"));
	 GameObjects.push_back(&sk33);


	 Kregiel k11 = Kregiel(3950, 240-60, 40, 60, &Kopernik, LoadTexture("kregiel.png"));
	 GameObjects.push_back(&k11);

	 Podloga podloga22= Podloga(3800, 240, 300);
	 podloga22.Setup();
	 GameObjects.push_back(&podloga22);

	 Kregiel k1111 = Kregiel(3950, 1800, 40, 60, &Kopernik, LoadTexture("kregiel.png"));
	 GameObjects.push_back(&k1111);

	 Podloga podloga23= Podloga(4300, 280, 450);
	 podloga23.Setup();
	 GameObjects.push_back(&podloga23);

	 Podloga podloga24 = Podloga(4850, 300, 300);
	 podloga24.Setup();
	 GameObjects.push_back(&podloga24);

	 Coin coin144 = Coin(5000, 300-16, 16, &Kopernik, coin_texture);
	 GameObjects.push_back(&coin144);

	 Podloga podloga25 = Podloga(5250, 350, 250);
	 podloga25.Setup();
	 GameObjects.push_back(&podloga25);

	 StrzelajacyKregiel sk3 = StrzelajacyKregiel(5450, 300, 40, 50, &Kopernik, LoadTexture("strzelajacy_kregiel.png"), LoadTexture("domek.png"));
	 GameObjects.push_back(&sk3);

	 Podloga podloga26 = Podloga(5600, 400, 100);
	 podloga26.Setup();
	 GameObjects.push_back(&podloga26);

	 Podloga podloga27 = Podloga(5700, 500, 100);
	 podloga27.Setup();
	 GameObjects.push_back(&podloga27);

	 Podloga podloga10 = Podloga(6200, 600, 1100);
	 podloga10.Setup();
	 GameObjects.push_back(&podloga10);

	 Podloga podloga11 = Podloga(6820, 520, 120);
	 podloga11.Setup();
	 GameObjects.push_back(&podloga11);

	 Podloga podloga12 = Podloga(6600, 470, 100);
	 podloga12.Setup();
	 GameObjects.push_back(&podloga12);

	 Podloga podloga13 = Podloga(5900, 540, 150);
	 podloga13.Setup();
	 GameObjects.push_back(&podloga13);

	 Coin coin13 = Coin(5900, 540-16, 16, &Kopernik, coin_texture);
	 GameObjects.push_back(&coin13);

	 Podloga podloga14 = Podloga(6500, 550, 100);
	 podloga14.Setup();
	 GameObjects.push_back(&podloga14);


	 Podloga podloga15 = Podloga(6940, 400, 100);
	 podloga15.Setup();
	 GameObjects.push_back(&podloga15);

	 Coin coin111 = Coin(7000, 400-16, 16, &Kopernik, coin_texture);
	 GameObjects.push_back(&coin111);

	 Podloga podloga16 = Podloga(6800, 440, 100);
	 podloga16.Setup();
	 GameObjects.push_back(&podloga16);

	 Podloga podloga17 = Podloga(6510, 400, 100);
	 podloga17.Setup();
	 GameObjects.push_back(&podloga17);

	  Podloga podloga18 = Podloga(7400, 600, 200);
	 podloga18.Setup();
	 GameObjects.push_back(&podloga18);

	 Kregiel k111 = Kregiel(7450, 540, 40, 60, &Kopernik, LoadTexture("kregiel.png"));
	 GameObjects.push_back(&k111);

	 Coin coin12 = Coin(7500, 600-16, 16, &Kopernik, coin_texture);
	 GameObjects.push_back(&coin12);

	  Podloga podloga19 = Podloga(7800, 750, 50);
	 podloga19.Setup();
	 GameObjects.push_back(&podloga19);

     
	   Podloga podloga20= Podloga(7800, 900, 2100);
	 podloga20.Setup();
	 GameObjects.push_back(&podloga20);


	 DomekZPiernikami Domek = DomekZPiernikami(4400, 80, 200, 200, &Kopernik, LoadTexture("domek.png"));
	 Domek.texture = LoadTexture("domek.png");
	 GameObjects.push_back(&Domek);

	 StrzelajacyKregiel k1 = StrzelajacyKregiel(4000, 230, 40, 60, &Kopernik, LoadTexture("strzelajacy_kregiel.png"), LoadTexture("domek.png"));
	 GameObjects.push_back(&k1);



	 StrzelajacyKregiel sk1 = StrzelajacyKregiel(1260, 400-50, 40, 50, &Kopernik, LoadTexture("strzelajacy_kregiel.png"), LoadTexture("domek.png"));
	 GameObjects.push_back(&sk1);

	 





    Shade2 shader1;
	shader1.area = {8300, 500, 1000, 2000};
	shader1.current = 0;
	shader1.velocity = 5;
	shader1.frequency = 20;

	 Knight boss1 = Knight(3200, 230, 100, 70, 240); 
	 boss1.limit_left =  2600;
	 boss1.limit_right = 3200;
	 boss1.velocity = 1.5;
	 boss1.is_left = false;
	 boss1.postac = &Kopernik;
	 boss1.texture = LoadTexture("knight.png");
	 GameObjects.push_back(&boss1);


	 PlanetGun *planet_gun =  new PlanetGun(6510, 400, 32, 32, 100);
	 planet_gun->positions[0] = Vector2{6540, 510};
	 planet_gun->positions[1] = Vector2{6540, 360};
	 planet_gun->positions[2] = Vector2{6840, 400};
	 planet_gun->positions[3] = Vector2{6870, 490};
	 planet_gun->positions[4] = Vector2{6940, 370};


	 planet_gun->velocity_x = 4;
	 planet_gun->is_left = &Kopernik.is_left;
	 planet_gun->friendly_hitbox = &Kopernik.general_hitbox;
	 
	


	 Trex *trex1 = new Trex(6900, 400, 200, 200);
	 trex1->laser_texture = LoadTexture("laser_texture.png");
	trex1->animation.source_texture = LoadTexture("trex.png");
	trex1->limit_right = 6900;
	trex1->limit_left = 6350;
	trex1->pause_time = 400;
	trex1->counter = 400;
	trex1->is_left = true;
	trex1->postac = &Kopernik;

	trex1->target_x = &Kopernik.x;
	trex1->target_y = &Kopernik.y;
	trex1->postac = &Kopernik;

	trex1->target_hitbox = &Kopernik.general_hitbox;
	trex1->target_hp = &Kopernik.hp;
	trex1->render_int = &current_frame;
	int kabanos = 5;
	trex1->boss_hp = &kabanos;

	trex1->positions.push_back({Vector2{6452, 498}, Vector2{7004-400, 498}});
	trex1->positions.push_back({Vector2{6462, 530}, Vector2{7044-400, 530}});
	trex1->positions.push_back({Vector2{6464, 568}, Vector2{7036-400, 568}});

	planet_gun->enemy_hitbox = &trex1->source_rectangle;

	planet_gun->enemy_hp = trex1->boss_hp;
	

   
   //  HorizontalHitboxes.push_back(&podloga2.general_hitbox);

	 

	// Create the window and OpenGL context

    
	


	// Load a texture from the resources directory
	// game variables
  
	Ender ender1 = Ender(8400, 800, 1, 1);


	
	int_fast8_t bullet_timer = 60;
	Kopernik.render = &current_frame;
	bool is_fullscrean = false;




	BlueBall ball1;
	ball1.x = 0;
	ball1.y = 0;
	ball1.radius = 10;



	std::sort(GameObjects.begin(), GameObjects.end(), ValueCmp);

    float render_distance = 2000.0F;
	// game loop
	while (!WindowShouldClose())		// run the loop untill the user presses ESCAPE or presses the Close button on the window
	{
        // check & render
        if(!IsSoundPlaying(sounds[sound_index])) PlaySound(sounds[sound_index]);


		if(is_boss_fight == 2) {
			Kopernik.camera.target = Vector2{6400, 260};
		}
		if(is_boss_fight == 1) {
			Kopernik.camera.target = Vector2{2600, -50};
		}
		if(Kopernik.x >= 9000) 	Kopernik.camera.target = Vector2{ender1.x, ender1.y};
		if(ender1.counter > 1300) {
			Kopernik.camera.target = {0, 0};
		}
		
		
        if(current_frame == 0) {
			
        HorizontalHitboxes.clear();
		Utilities.clear();
		Enemies.clear();
	   
		
        
		float current_x = Kopernik.x;
		float current_y = Kopernik.y;

	          auto obj = std::lower_bound(GameObjects.begin(), GameObjects.end(), current_x, [](auto a, auto b) {return a->x < b;} );
	          int dist = std::distance(GameObjects.begin(), obj);
            
			  if(dist > 0) dist--;
			
              
			  for(int j = dist; j < GameObjects.size(); j++) {
                if(current_x + render_distance - GameObjects[j]->x  < 0) break;

				if(GameObjects[j]->OT == HITBOX) {
                   if(GameObjects[j]->HT == HORIZONTAL) HorizontalHitboxes.push_back(GameObjects[j]);
				}
				if(GameObjects[j]->OT == UTILITY) {
					Utilities.push_back(GameObjects[j]);
				}
				if(GameObjects[j]->OT == ENEMY) {
					Enemies.push_back(GameObjects[j]);
				}
			
			}

				for(int j = dist-1; j >= 0; j--) {
					if(current_x - GameObjects[j]->x > render_distance) break;
	
					if(GameObjects[j]->OT == HITBOX) {
					   if(GameObjects[j]->HT == HORIZONTAL) HorizontalHitboxes.push_back(GameObjects[j]);
					}
					if(GameObjects[j]->OT == UTILITY) {
					 	Utilities.push_back(GameObjects[j]);
					 }

					 if(GameObjects[j]->OT == ENEMY) {
						Enemies.push_back(GameObjects[j]);
					}
					
				}
				
			
		

		}
		current_frame++;
		if(current_frame == 400) current_frame = 0;
     
 
		// fullscrean
      //  Kopernik.dy = 0;
		if(IsKeyPressed(KEY_F11)) {
			ToggleBorderlessWindowed();
          if(!is_fullscrean) {
            Kopernik.camera.zoom = 3.0F;
			 Kopernik.dx -= 50;
			 Kopernik.dy += 50;
		

		   is_fullscrean = true;
		  } else {
		   Kopernik.camera.zoom =  1.0F;
		     Kopernik.dx += 50;
		     Kopernik.dy -= 50;
		  

		   is_fullscrean = false;
		  }

		}
		BeginDrawing();

		
		BeginMode2D(Kopernik.camera);

    

	
        map.Draw();
       
		for(int j = 0; j < Utilities.size(); j++) {
			Utilities[j]->Draw();
		}

		for(int j = 0; j < Enemies.size(); j++) {
			Enemies[j]->Draw();
		}
     

	
		 
		

		for(int j = 0; j < HorizontalHitboxes.size(); j++) {
			HorizontalHitboxes[j]->DrawHitbox();
		}
      

	
		Kopernik.DrawHealthBar();  // kopernik draw pasek zdrowia
		Kopernik.Draw();
		train1.Draw();
		train1.Update(Kopernik.x, Kopernik.is_hibernated);
	//  Kopernik.Draw();

		DrawText(TextFormat("%d %s", coin_ammount, "zl"), Kopernik.x+8, Kopernik.y-30, 10, YELLOW);
		
		
		for(int j = 0; j < bullets.size(); j++) {
			bullets[j].Draw();
		}

		// updates
	
		if(2600 < Kopernik.x  && Kopernik.x < 3200 && boss1.hp > 0) {
           is_boss_fight = 1;
		   PauseAllSoundsExcept(sounds, 1);
		   sound_index = 1;
		   
		} else if(6300 < Kopernik.x && Kopernik.x < trex1->limit_right+150 && *trex1->boss_hp > 0) {
          is_boss_fight = 2;
		  sound_index = 2;
		  PauseAllSoundsExcept(sounds, 2);
		} else {
 
			if(*trex1->boss_hp > 0) {
			sound_index = 0;
			PauseAllSoundsExcept(sounds, 0);
			}
		  is_boss_fight = 0;

		  if(*trex1->boss_hp <= 0) {
			sound_index = 4;
		//	PauseSound(sounds[2]);
			PauseAllSoundsExcept(sounds, 4);
		  }
           
       
		 
		}

	

	
		Kopernik.Update();
		if(IsMouseButtonPressed(0) && !Kopernik.is_hibernated) {
			if(Kopernik.is_left) {
				bullets.push_back(Bullet(Kopernik.x+18, Kopernik.y+28, 20, -6, 180, ammo_texture));
			} else {
				bullets.push_back(Bullet(Kopernik.x+18, Kopernik.y+28, 20, 6, 180, ammo_texture));
			}
		}

 
		
		for(int k = 0; k < bullets.size(); k++) {
			bullets[k].Update();
			for(int j = 0; j < Enemies.size(); j++) {
				if(Enemies[j] == nullptr) continue;
				if(CheckCollisionRecs(bullets[k].general_hitbox, Enemies[j]->general_hitbox) && bullet_timer > 0) {
                   bullets[j].timer = 0;
				   Enemies[j]->hp--;
				}
				
			}
			if(bullets[k].timer <= 0) bullets.erase(bullets.begin()+k, bullets.begin()+k+1);
		}

		for(int j = 0; j < HorizontalHitboxes.size(); j++) {
			Kopernik.is_colliding_bottom_hitbox = false;

			if(CheckCollisionRecs(Kopernik.bottom_hitbox, HorizontalHitboxes[j]->general_hitbox)) {
				Kopernik.is_colliding_bottom_hitbox = true;
				break;
			} 
		}

		for(int j = 0; j < Utilities.size(); j++) {
			Utilities[j]->Update();
			if(Utilities[j]->should_destroy) {
				GameObject* target = Utilities[j];
				Remove(GameObjects, target);
				Remove(Utilities, target);
				// delete target;
				current_frame = 0;
			}
		}


		for(int j = 0; j < Enemies.size(); j++) {
			Enemies[j]->Update();
			if(Enemies[j]->should_destroy) {
				GameObject* target = Enemies[j];
				Remove(GameObjects, target);
				Remove(Enemies, target);
				//if(Enemies[j] != nullptr) delete target;
				current_frame = 0;
			}
		}
	//	if(2500 < Kopernik.x && Kopernik.x < 3200) is_boss_fight = true;
        
    
	
		// boss1->Update();
		trex1->Draw();
		trex1->Update();

		ball1.Draw();
		ball1.Update();

		ball1.tp_x = &Kopernik.x;
		ball1.tp_y = &Kopernik.y;


		planet_gun->Update();
		planet_gun->DrawHitbox();

		if(Kopernik.x >= 9000)  {
		
			shader1.Draw();
			shader1.Update();

			if(shader1.current > 250) {
				ender1.Draw();
				if(ender1.counter > 240) {
                  ender1.Update();
				}
			}
		}
		if(ender1.counter > 1300) {
			DrawTexture(baner, 0, 0, WHITE);
		}


		
    // Vector2 pos = GetMousePosition();
	//     DrawText(TextFormat("%F, %F", pos.x, pos.y), Kopernik.camera.target.x+200, Kopernik.camera.target.y, 30, BLACK);
		ClearBackground(Color{100, 100, 255, 0});
		//DrawText(TextFormat("%f", source.x), 600, 130, 20, RED);
		// end the frame and get ready for the next one  (display frame, poll input, etc...)
		EndMode2D();
		EndDrawing();
	}

	// cleanup
	// unload our texture so it can be cleaned up

    CloseAudioDevice();
	// destroy the window and cleanup the OpenGL context
	CloseWindow();
	return 0;
}
