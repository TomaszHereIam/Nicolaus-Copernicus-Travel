#pragma once
#include "animation.hpp"

void Animation::Animate(int start_x, int start_y, int end_x, int end_y) {
     counter++;
     if(counter == frequency) {
       counter = 0;
       current_frame++;
   
       k++;
       if(k > end_x) {
         k = start_x;
         l++;
         if(l > end_y) {
           l = start_y;
         }
       }
   
       source_rectangle.x = (k-1)*width;
       source_rectangle.y = (l-1)*height;
   
     }
     if(current_frame > start_x*start_y) current_frame = 1;
   
   }
   
   void Animation::SetCurrentFrame(int frame) { // the basic concept to this void is equivalent to residue dividing
    counter = 0;
   // if(frame > m*n) return;
     k = frame%m;
     l = frame/m+1;
     if(frame % m == 0)  {
      k = m;
      l = frame/m;
     }
 
     current_frame = frame;
    //  k = (current_frame%m);
    //  l = (current_frame/m)+1;
    // if(pause) current_frame++;
      source_rectangle.x = (k-1)*width;
      source_rectangle.y = (l-1)*height;
  }
  void Animation::NextFrame() {
    SetCurrentFrame(current_frame+1);
  }

   
   void Animation::Draw() {
    if(is_left)  source_rectangle.width *= -1;
     DrawTexturePro(source_texture, source_rectangle, *dest_rectangle, Vector2{0, 0}, 0.0F, WHITE);
     if(is_left)  source_rectangle.width *= -1;
    DrawText(TextFormat("%d", current_frame), 100, 100, 20, BLUE);
   }

   void Animation::Reset() {
    SetCurrentFrame(1);
}



 //

 //





void OneTimeAnimation::Draw() {
  DrawTexturePro(source_texture, source_rectangle, dest_rectangle, Vector2{0, 0}, 0.0F, WHITE);

  DrawText(TextFormat("%d", current_frame), 100, 100, 20, BLUE);
}

void OneTimeAnimation::Reset() {
      current_frame = 1;
      counter = 0;
      k = 1;
      l = 1;
      pause = false;
  }

  void OneTimeAnimation::Animate(int start_x, int start_y, int end_x, int end_y) {
    if(current_frame >= end_x*end_y) pause = true;
   if(!pause) counter++; 
   if(current_frame > (m*n)) current_frame = 1;
    if(!pause &&counter == frequency) {
      counter = 0;
      current_frame++;
  
      k++;
      if(k > end_x) {
        k = start_x;
        l++;
        if(l > end_y) {
          l = start_y;
        }
      }
  
      
  
    }
      source_rectangle.x = (k-1)*width;
      source_rectangle.y = (l-1)*height;
  
  }
  
  void OneTimeAnimation::NextFrame() {
    counter = frequency;
  }
  
  void OneTimeAnimation::SetCurrentFrame(int frame) { // the basic concept to this void is equivalent to residue dividing
    counter = 0;
   // if(frame > m*n) return;
     k = frame%m;
     l = frame/m+1;
     if(frame % m == 0)  {
      k = m;
      l = frame/m;
     }
 
     current_frame = frame;
    //  k = (current_frame%m);
    //  l = (current_frame/m)+1;
    // if(pause) current_frame++;
      source_rectangle.x = (k-1)*width;
      source_rectangle.y = (l-1)*height;
  }


