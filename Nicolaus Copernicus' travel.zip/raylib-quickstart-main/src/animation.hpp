#ifndef ANIMATION_HPP
#define ANIMATION_HPP
#include "raylib.h"



class Animation { // NOTE: Source and destination rectangle have the same dimensions
  private:
  int counter = 0;
  public:

  float x;
  float y;
  float width;
  float height;
  


    int m;
    int n;
    int frequency;
    int current_frame = 1;

    Texture source_texture; // spritesheet
    

    int k = 1; // coefficient
    int l = 1; //  coefficient
 


    Rectangle source_rectangle;
    Rectangle* dest_rectangle;
    bool is_left = false;
    
    Animation(float get_x, float get_y, float get_width, float get_height, int get_m, int get_n) {
        x = get_x;
        y = get_y;
        width = get_width;
        height = get_height;

        m = get_m;
        n = get_n;


       
        source_rectangle = Rectangle{0, 0, width, height};

    }
    Animation() {

    }
     
   

    void Animate(int start_x, int start_y, int end_x, int end_y);
    void NextFrame();
    void SetCurrentFrame(int frame);
    void Draw();
    void Reset();
  //  void Setup();
};


class OneTimeAnimation { // NOTE: Source and destination rectangle have the same dimensions
  private:
  int counter = 0;
  public:

  float x;
  float y;
  float width;
  float height;



    int m;
    int n;
    int frequency;
    int current_frame = 1;
    bool pause = false;

    Texture source_texture; // spritesheet
    

    int k = 1; // coefficient
    int l = 1; //  coefficient
 


    Rectangle source_rectangle;
    Rectangle dest_rectangle;

    
    OneTimeAnimation(float get_x, float get_y, float get_width, float get_height, int get_m, int get_n) {
        x = get_x;
        y = get_y;
        width = get_width;
        height = get_height;

        m = get_m;
        n = get_n;


        dest_rectangle = Rectangle{x, y, width, height};
        source_rectangle = Rectangle{0, 0, width, height};

    }

    OneTimeAnimation() {
      
    }
     
   

    void Animate(int start_x, int start_y, int end_x, int end_y);
    void NextFrame();
    void SetCurrentFrame(int frame);
    void Draw();
    void Reset();
  //  void Setup();
};
  #endif