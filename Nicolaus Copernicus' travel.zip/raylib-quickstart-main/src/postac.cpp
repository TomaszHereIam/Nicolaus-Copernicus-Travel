
#pragma once

#include "postac.hpp"





void Postac::Draw() {
 animation.Draw();
}

void Postac::DrawHitbox() {
 DrawRectangleRec(general_hitbox, RED);
 DrawRectangleRec(top_hitbox, YELLOW);
 DrawRectangleRec(bottom_hitbox, YELLOW);
 DrawRectangleRec(right_hitbox, YELLOW);
 DrawRectangleRec(left_hitbox, YELLOW);
}

void Postac::DrawHealthBar() {
  DrawRectangle(x+2, y-10, 3*hp, 5, GREEN);
}

void Postac::Setup() {
  general_hitbox.width = width;
  general_hitbox.height = height;
  top_hitbox.width = width-8;
  top_hitbox.height = 4;
  bottom_hitbox.width = width-8;
  bottom_hitbox.height = 4;
  right_hitbox.width = 4;
  right_hitbox.height = height-8;
  left_hitbox.width = 4;
  left_hitbox.height = height-8;

  

  // fps config
  
  

  velocity_x = (velocity_x)/fps;
  jump_time*=fps;
  jump_timer = jump_time;

  // camera
  camera.rotation = 0.0f;
  camera.zoom = 1.0f;

  // draw
  animation.dest_rectangle = &general_hitbox;


  respawn_x = 0;
  respawn_y = 300;
}

void Postac::Respawn() {
  x = respawn_x;
  y = respawn_y;
  *render = 0;
  hp = max_hp;
}

void Postac::Update() {
   if(hp > max_hp) max_hp = hp;
    
    if(hp <= 0 || y >= max_y) {
      Respawn();
      return;
    }
    // movement
    if(!is_hibernated) {
    if(IsKeyDown(KEY_D) && !is_colliding_right_hitbox) {
      x+=velocity_x;
    }
    if(IsKeyDown(KEY_A) && !is_colliding_left_hitbox) {
      x-=velocity_x;
    }


    // jump
    if(IsKeyPressed(KEY_SPACE) && is_colliding_bottom_hitbox) {
      if(jump_timer == jump_time) {
        jump_timer--;
        is_jumping = true;
      }
    }

    if(jump_timer < jump_time) {
      y-=jump_power;
      jump_timer--;
    }
    if(jump_timer == 0) {
      jump_timer = jump_time;
      is_jumping = false;
    }

    if(!is_colliding_bottom_hitbox && jump_timer == jump_time) {
      fall_velocity+=(gravity/float(fps));
      y+=fall_velocity;
    } else {
      fall_velocity = 0;
    }

    


    // draw


    if(IsKeyDown(KEY_A) != IsKeyDown(KEY_D))  animation.Animate(2, 1, 4, 1);
   
    if(IsKeyDown(KEY_A) ) {
      if(animation_frame == frequency) {
        animation_frame = 0;
      }
      is_left = true;
    }
    if(IsKeyDown(KEY_D)) {
        if(animation_frame == frequency) {
      animation_frame = 0;
    }
   

      is_left = false;
  }

  if(IsKeyDown(KEY_A) == IsKeyDown(KEY_D)) {
    animation.Reset();
   // DrawText("kregle", x+100, y+100, 20, BLUE);
  }
  if(!is_colliding_bottom_hitbox) {
    animation.source_rectangle = Rectangle{36, 56, 36, 56};
  }


}


 
  
   // camera
   // camera
   camera.target = Vector2{x + dx, -100+y/2};

   // only this game update

   if(x > 5600) camera.target.y = 20+y/2;

   if(x > 7400) camera.target.y = 120+y/2;

   if(x > 9000) is_hibernated = true;
    // hitbox updates

    // standard hitbox space is 2
    general_hitbox.x = x;
    general_hitbox.y = y;
    top_hitbox.x = x+4;
    top_hitbox.y = y;
    bottom_hitbox.x = x+4;
    bottom_hitbox.y = y+height-bottom_hitbox.height;
    right_hitbox.x=x+width-right_hitbox.width;
    right_hitbox.y=y+4;
    left_hitbox.x=x;
    left_hitbox.y=y+4;
   
   
    animation.is_left = is_left;

}

