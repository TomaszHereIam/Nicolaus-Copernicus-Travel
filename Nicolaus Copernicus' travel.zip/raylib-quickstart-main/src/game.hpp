#ifndef GAME_HPP
#define GAME_HPP
#include "raylib.h"
#include "cstdint"


typedef int_fast8_t               HitboxType;

#ifndef NONE
#define NONE               0
#endif

#ifndef VERTICAL
#define VERTICAL             1
#endif

#ifndef HORIZONTAL
#define HORIZONTAL          2
#endif

#ifndef BOTH
#define BOTH               3
#endif


typedef int_fast8_t               ObjectType;

#ifndef HITBOX
#define HITBOX              0
#endif

#ifndef UTILITY
#define UTILITY            1
#endif

#ifndef ENEMY
#define ENEMY         2
#endif

// the objects should be sorted by x

class Mapa {
 public:
 float x;
 float y;
 float width;
 float height;

 
 Texture texture;
 
 void Draw();
 void DrawHitbox();
};

class GameObject {
    public:

    ObjectType OT;
    HitboxType HT;
    
   
    float x;
    float y;
    float width;
    float height;

    int hp = 0;

    Rectangle general_hitbox;

    bool should_destroy = false;

    void DrawHitbox();
    virtual void Update();
    virtual void Draw();
};

class StaticObject : public GameObject {
  public:
  void Update() {}
  void Draw() {}
};





class Checkpoint :  public GameObject {
 public:
 int is_checked = 0;

 float *x_now;
 float *y_now;
 float *current_respawn_x;
 float *current_respawn_y;


 Texture spritesheet; // the spritesheet here is always 1 x 2
 Checkpoint(float get_x, float get_y, float get_width, float get_height) {
    x = get_x;
    y = get_y;
   width = get_width;
    height = get_height;

    general_hitbox = Rectangle{x, y, width, height};

    OT = UTILITY;
    HT = NONE;
 }


 void Draw();
 void Update();
};

class Podloga : public StaticObject {
  public:



  Podloga(float get_x, float get_y, float get_width) {
    x = get_x;
    y = get_y;
    height = 4;
    width = get_width;

    OT = HITBOX;
    HT = HORIZONTAL;
    
  }
 
    void Setup();
  

  
};

class Enemy : public GameObject{
  public:
 int hp;
};


class Sciana : public StaticObject {
  public:



  Sciana(float get_x, float get_y, float get_height) {
    x = get_x;
    y = get_y;
    height = get_height;
    width = 4;

    OT = HITBOX;
    HT = VERTICAL;

    general_hitbox = Rectangle{x, y, width, height};
  }
  
  Sciana() {

  }
};

class Train : public  GameObject {
 public:
 Texture texture;

 
 float destinition;
 float vx;
 bool can_unhibarnate = true;


 Train(float get_x, float get_y,float get_dest, int time) {
  x = get_x;
  y = get_y;
  destinition = get_dest;
   vx = (get_dest - x) / (float) time;
 }


 void Draw() {
  DrawTexture(texture, x, y, WHITE);
 }
 void Update(float &target_x, bool &target_bool) {
  if(can_unhibarnate) {
  if(x >= destinition) {target_bool = false; can_unhibarnate = false;} else {
   x+=vx;
   target_x+=vx;
  }
 }
}

};


#endif
// 

