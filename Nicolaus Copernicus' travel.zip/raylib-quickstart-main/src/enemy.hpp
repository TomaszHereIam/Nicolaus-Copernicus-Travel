#include "raylib.h"
#include "game.hpp"
#include "animation.hpp"
#include <vector>

class Przeciwnik {
 public:
 int hp;
};

class DarkKnight : public Przeciwnik, public GameObject {
 public:
 //void kabanos();
};


#include "raylib.h"
#include "game.hpp"

class Trex : public GameObject {
	private:
	int random_num;
	public:

	Animation animation = Animation(0, 0, 200, 200, 4, 1);

	
	float limit_right;
	float limit_left;
	bool is_left = false;
	bool is_paused = false;
	int pause_time;
	int counter = 0;
    Texture laser_texture;

	Rectangle attack_rectngle;

	
	std::vector<Vector2> positions;
	
	Trex(float get_x, float get_y, float get_width, float get_height) {
		x = get_x;
		y = get_y;
		width = get_width;
		height = get_height;
	
		general_hitbox = Rectangle{x, y, width, height};
		animation.dest_rectangle = &general_hitbox;

		
       // animation.frequency == -1;
	 //	Animation.animate(1, 2, 3)
	
	}
	void DrawHitbox() {
		DrawRectangleLinesEx(general_hitbox, 4, RED);
	}

   
	void Update() {
		if(counter < pause_time){
			
			counter--;
		}

		if(counter == 0) {
			counter = pause_time;
			is_paused = false;

			if(is_left && x > limit_left) x-=1;
            if(!is_left && x < limit_right)  x+=1;
			
		}

		animation.is_left = is_left;

		if(is_paused && counter > 0) counter--;

		// movement & attack
	if(!is_paused) {	
		if(is_left && x > limit_left) x-=1;
        if(!is_left && x < limit_right)  x+=1;
		
		if(x <= limit_left) {

		is_left = false; is_paused = true; 
		random_num = 2; // GetRandomValue(0, 2);
	    animation.SetCurrentFrame(random_num+1);
		attack_rectngle = Rectangle{positions[random_num].x, positions[random_num].y, 600, 20}; 

	}
		if(x >= limit_right) {
			
			is_left = true; is_paused = true; 
		
			random_num = random_num = 2;
			animation.SetCurrentFrame(random_num+1);
			attack_rectngle = Rectangle{positions[random_num].x, positions[random_num].y, 400, 20}; 
		}
     
		general_hitbox = Rectangle{x, y, width, height};
	}
		
	 
	  if(counter == (pause_time/2)-1) animation.SetCurrentFrame(1);
 	}

	void DrawLaser() {
		if(is_left) {
			attack_rectngle.x = x - 300;
			positions[random_num].x = x - 200;
		}
		DrawTexturePro(laser_texture, Rectangle{0, 0, 40, 20}, attack_rectngle, Vector2{0, 0}, 0.0F, WHITE);

		if(is_left) {
			attack_rectngle.x = x - 300;
			positions[random_num].x = x - 200;
		}
	  }
	void Draw() {
     animation.Draw();
	 if(pause_time > counter && counter > pause_time/2) DrawLaser();
	}
 
	
  };