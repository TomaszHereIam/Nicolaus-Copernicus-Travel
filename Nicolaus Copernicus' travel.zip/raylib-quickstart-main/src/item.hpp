#include "raylib.h"
#include <vector>

// class Bullet {
// 	public:
// 	int timer;
// 	Texture texture;
	
   
// 	float x;
// 	float y;
// 	float side;
// 	float vx;
// 	float lifespan;
   
// 	Rectangle general_hitbox;
   
// 	Bullet(float get_x, float get_y, float get_side, float get_vx, float get_lifespan, Texture get_texture) {
// 	  x = get_x;
// 	  y = get_y;
// 	  side = get_side;
// 	  lifespan = get_lifespan;
// 	  vx = get_vx;
// 	  timer = lifespan;
   
// 	  general_hitbox = Rectangle{x, y, side, side};
   
   
// 	  texture = get_texture;
   
// 	}
   
// 	void Draw() {
// 		DrawTexture(texture, x, y, WHITE);
// 	}
	
// 	void DrawHitbox() {
// 		DrawRectangleLinesEx(general_hitbox, 4, RED);
// 	}
	
	
// 	void Update() {
// 	  x+=vx;
// 	  general_hitbox.x+=vx;
	
// 	  timer--;
// 	}
   
//    };